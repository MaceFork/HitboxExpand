package com.example.hitboxexpand;

import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.SliderWidget;
import net.minecraft.text.Text;

public final class HitboxExpandScreen extends Screen {
    private int panelX, panelY, panelW = 260, panelH = 190;

    public HitboxExpandScreen() {
        super(Text.literal("Hitbox Expand"));
    }

    @Override
    protected void init() {
        panelX = (width - panelW) / 2;
        panelY = (height - panelH) / 2;
        int x = panelX + 15;
        int w = panelW - 30;

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Expand: " + (HitboxExpandClient.enabled ? "ON" : "OFF")),
                b -> {
                    HitboxExpandClient.enabled = !HitboxExpandClient.enabled;
                    b.setMessage(Text.literal("Expand: " + (HitboxExpandClient.enabled ? "ON" : "OFF")));
                    HitboxExpandClient.notify(client, HitboxExpandClient.enabled ? "Enabled" : "Disabled");
                }).dimensions(x, panelY + 35, w, 20).build());

        addDrawableChild(new SliderWidget(x, panelY + 65, w, 20,
                Text.literal("Size: " + String.format(java.util.Locale.ROOT, "%.2f", HitboxExpandClient.expansion)),
                (HitboxExpandClient.expansion - 0.1) / 1.9) {
            @Override
            protected void updateMessage() {
                setMessage(Text.literal("Size: " + String.format(java.util.Locale.ROOT, "%.2f", HitboxExpandClient.expansion)));
            }

            @Override
            protected void applyValue() {
                HitboxExpandClient.expansion = 0.1 + value * 1.9;
            }
        });

        addDrawableChild(ButtonWidget.builder(
                Text.literal("Combat tools only: " + (HitboxExpandClient.combatToolsOnly ? "ON" : "OFF")),
                b -> {
                    HitboxExpandClient.combatToolsOnly = !HitboxExpandClient.combatToolsOnly;
                    b.setMessage(Text.literal("Combat tools only: " + (HitboxExpandClient.combatToolsOnly ? "ON" : "OFF")));
                }).dimensions(x, panelY + 95, w, 20).build());

        addDrawableChild(ButtonWidget.builder(Text.literal("Close"), b -> close())
                .dimensions(x, panelY + 145, w, 20).build());
    }

    @Override
    public void render(DrawContext context, int mouseX, int mouseY, float delta) {
        renderBackground(context, mouseX, mouseY, delta);
        context.fill(panelX, panelY, panelX + panelW, panelY + panelH, 0xEE171421);
        int borderColor = 0xFFB84DFF;
        context.fill(panelX, panelY, panelX + panelW, panelY + 1, borderColor);
        context.fill(panelX, panelY + panelH - 1, panelX + panelW, panelY + panelH, borderColor);
        context.fill(panelX, panelY, panelX + 1, panelY + panelH, borderColor);
        context.fill(panelX + panelW - 1, panelY, panelX + panelW, panelY + panelH, borderColor);
        context.drawCenteredTextWithShadow(textRenderer, title, width / 2, panelY + 12, 0xFFE06BFF);
        context.drawCenteredTextWithShadow(textRenderer, "Players only • Insert to open", width / 2, panelY + 120, 0xFFFFFFFF);
        super.render(context, mouseX, mouseY, delta);
    }

    @Override
    public boolean shouldPause() {
        return false;
    }
}
