package com.example.hitboxexpand.mixin;

import com.example.hitboxexpand.HitboxExpandClient;
import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.Entity;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.Box;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.At;
import org.spongepowered.asm.mixin.injection.Inject;
import org.spongepowered.asm.mixin.injection.callback.CallbackInfoReturnable;

@Mixin(Entity.class)
public abstract class EntityHitboxMixin {
    @Inject(method = "getBoundingBox", at = @At("RETURN"), cancellable = true)
    private void hitboxexpand$expandPlayerBox(CallbackInfoReturnable<Box> cir) {
        Entity self = (Entity) (Object) this;
        MinecraftClient client = MinecraftClient.getInstance();

        if (!(self instanceof PlayerEntity)) return;
        if (client.player == null || self == client.player) return;
        if (!HitboxExpandClient.shouldExpand(client)) return;

        double amount = HitboxExpandClient.expansion;
        Box original = cir.getReturnValue();
        cir.setReturnValue(original.expand(amount, amount, amount));
    }
}
