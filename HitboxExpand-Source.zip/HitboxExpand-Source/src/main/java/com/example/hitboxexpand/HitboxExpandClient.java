package com.example.hitboxexpand;

import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.KeyBinding;
import net.minecraft.client.util.InputUtil;
import net.minecraft.text.Text;
import org.lwjgl.glfw.GLFW;

public final class HitboxExpandClient implements ClientModInitializer {
    public static boolean enabled = false;
    // Extra amount added to each side of the target's bounding box.
    public static double expansion = 0.5;
    public static boolean combatToolsOnly = true;

    private static KeyBinding openGuiKey;

    @Override
    public void onInitializeClient() {
        openGuiKey = KeyBindingHelper.registerKeyBinding(new KeyBinding(
                "key.hitboxexpand.open_gui",
                InputUtil.Type.KEYSYM,
                GLFW.GLFW_KEY_INSERT,
                KeyBinding.Category.MISC
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (openGuiKey.wasPressed()) {
                if (client.currentScreen == null) {
                    client.setScreen(new HitboxExpandScreen());
                } else if (client.currentScreen instanceof HitboxExpandScreen) {
                    client.setScreen(null);
                }
            }
        });
    }

    public static boolean shouldExpand(MinecraftClient client) {
        if (!enabled || client == null || client.player == null || client.world == null) return false;
        if (!combatToolsOnly) return true;
        var stack = client.player.getMainHandStack();
        if (stack.isEmpty()) return false;
        String id = net.minecraft.registry.Registries.ITEM.getId(stack.getItem()).getPath();
        // Covers vanilla swords, axes, mace, trident and spear-named items/modded spear items.
        return id.endsWith("_sword") || id.endsWith("_axe") || id.equals("mace")
                || id.equals("trident") || id.contains("spear");
    }

    public static void notify(MinecraftClient client, String message) {
        if (client.player != null) client.player.sendMessage(Text.literal("[Hitbox Expand] " + message), true);
    }
}
