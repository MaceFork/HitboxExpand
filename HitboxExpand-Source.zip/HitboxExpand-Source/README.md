# Hitbox Expand — source project

Client-side Fabric starter project for Minecraft Java 1.21.11. Intended controls:
- Press **Insert** to open the settings GUI.
- Toggle expansion on/off.
- Adjust expansion size.
- Restrict expansion to when a combat item is held.
- Target other player entities only.

## Build on GitHub Actions / a computer
Use Java 21 and run:

```sh
gradle build
```

The JAR should be in `build/libs/`.

## Important compatibility notes
This is source code, not a tested ready-to-install JAR. Minecraft/Fabric APIs and dependency versions can change; if Gradle reports a missing mapping/dependency or GUI API symbol, adjust the versions/API calls to the exact 1.21.11 setup and rebuild. Test in a local world first.

This modifies client-side bounding-box results only. It does not change server hit detection and cannot guarantee expanded hits on multiplayer servers. Use only where permitted by the server rules.
